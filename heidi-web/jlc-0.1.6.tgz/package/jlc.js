import * as wasm from "./jlc_bg.wasm";
export * from "./jlc_bg.js";
import { __wbg_set_wasm } from "./jlc_bg.js";
__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
