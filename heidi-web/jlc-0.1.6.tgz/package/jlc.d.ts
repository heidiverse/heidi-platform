/* tslint:disable */
/* eslint-disable */
export function get_json_logic(normal: string): string;
export function validate_logic(normal: string): boolean;
export function evaluate_aifc(normal: string, data: string): string;
export function apply_logic(logic: string, data: string): string;
export function to_qrcode(payload: string): string;
export function from_qrcode(payload: string): string;
